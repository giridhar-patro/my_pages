# Favorite Movies List - Final code

A Pen created on CodePen.io. Original URL: [https://codepen.io/nweat/pen/ZjyMEe](https://codepen.io/nweat/pen/ZjyMEe).

