# To-Do List, Plain JS

A Pen created on CodePen.io. Original URL: [https://codepen.io/JohnPaulFich/pen/MXmzzM](https://codepen.io/JohnPaulFich/pen/MXmzzM).

